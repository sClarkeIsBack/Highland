import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmhpZ2hsYW5kaXB0dg==')

name = b.b64decode('SGlnaGxhbmQgSVBUVg==')

host = b.b64decode('aHR0cDovL2lwaGlnaGxhbmQuY28udWs=')

port = b.b64decode('ODA=')